# play-swagger-ui
Playframework 1.3 module for swagger ui
